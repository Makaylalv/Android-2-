package com.help.software.helpeachother.code.Record_ViewPager;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;

import com.help.software.helpeachother.R;


public class BaseRecordViewPager {
    public Activity mActivity;
    public View rootView;
    public FrameLayout fl_record_pager;
    public BaseRecordViewPager(Activity mActivity){
        this.mActivity=mActivity;
        rootView=initView();
    }
    public View initView(){
        rootView=View.inflate(mActivity, R.layout.base_record_pager,null);
        fl_record_pager= (FrameLayout) rootView.findViewById(R.id.fl_record_pager);
        return rootView;
    }
    public  void initData(){}
}
