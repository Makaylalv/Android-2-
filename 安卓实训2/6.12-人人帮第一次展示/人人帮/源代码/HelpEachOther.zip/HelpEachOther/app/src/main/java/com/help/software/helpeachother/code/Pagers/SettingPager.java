package com.help.software.helpeachother.code.Pagers;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.help.software.helpeachother.Bean._User;
import com.help.software.helpeachother.code.Activity.MainActivity;
import com.help.software.helpeachother.R;
import com.help.software.helpeachother.code.Activity.About_Activity;
import com.help.software.helpeachother.code.Activity.AdTogether;
import com.help.software.helpeachother.code.Activity.ContactMe;
import com.help.software.helpeachother.code.Activity.FeedBack;
import com.help.software.helpeachother.code.Activity.HelpFenLei;
import com.help.software.helpeachother.code.Activity.Laws;
import com.help.software.helpeachother.code.Activity.PersonalCenterActivity;
import com.help.software.helpeachother.code.Activity.ReceiveAddressList;
import com.help.software.helpeachother.code.Activity.SystemMessage;
import com.help.software.helpeachother.code.Fragment.LeftMenuFragMent;
import com.help.software.helpeachother.code.Util.MyToast;
import com.help.software.helpeachother.code.Util.MyToastForBlue;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.DownloadFileListener;

public class SettingPager extends BasePager {
    private Activity mActivity;
    private Button message;
    private LinearLayout ll_money,ll_i_help,ll_help_i;
    private CardView cardView;
    public boolean comeonline = false;
    private ImageView iv_setting_person;
    private CardView exit;
    private _User userInfo;


    //头像
    private BmobFile bmobFile;
    private ImageView pic_me;

    public TextView address, add_AD, question, laws, feed_back, about, settings, come_online, counter_help, counter_forhelp, sign;

    public SettingPager(Activity mActivity) {
        super(mActivity);
        this.mActivity = mActivity;

    }

    @Override
    public View initView() {

        return super.initView();
    }

    @Override
    public void initData() {
        //让toolbar消失
        relativeLayout.setVisibility(View.GONE);
        init();
    }

    private void init() {
        View view = View.inflate(mActivity, R.layout.person_center_pager, null);
        address =  view.findViewById(R.id.address);
        about =  view.findViewById(R.id.about);
        add_AD =  view.findViewById(R.id.add_AD);
        laws =  view.findViewById(R.id.laws);
        feed_back =  view.findViewById(R.id.feed_back);
        settings =  view.findViewById(R.id.settings);
        cardView =  view.findViewById(R.id.online_cardview);
        come_online =  view.findViewById(R.id.come_online);
        exit =  view.findViewById(R.id.online_cardview);
        iv_setting_person =  view.findViewById(R.id.iv_setting_person);
        sign =  view.findViewById(R.id.tv_sign);
        ll_money=  view.findViewById(R.id.my_credit);
        ll_i_help=  view.findViewById(R.id.count_my_help);
        ll_help_i=  view.findViewById(R.id.count_for_help);
        message =  view.findViewById(R.id.message);

        pic_me=view.findViewById(R.id.iv_setting_person);

        //检测登陆
        userInfo = BmobUser.getCurrentUser(_User.class);
        if (userInfo != null) {
            comeonline = true;
            //如果登陆了，则显示个性签名！
            sign.setVisibility(View.VISIBLE);
            exit.setVisibility(View.VISIBLE);
            if (userInfo.getMyname() == null) {
                come_online.setText(userInfo.getUsername());
                if (userInfo.getDes() == null) {
                    sign.setText("这家伙很懒，什么都没留下");
                } else {
                    sign.setText(userInfo.getDes());
                }
            } else {

                bmobFile=userInfo.getAvatar();

                Glide.with(mActivity).load(bmobFile.getFileUrl()).into(pic_me);
                //
                if (userInfo.getDes() == null) {
                    sign.setText("这家伙很懒，什么都没留下");
                } else {
                    if (userInfo.getDes().equals("未设置")) {
                        sign.setText("这家伙很懒，什么都没留下");
                    } else {
                        sign.setText(userInfo.getDes());
                    }
                }
                come_online.setText(userInfo.getMyname());
            }
        } else {
            comeonline = false;
            sign.setVisibility(View.INVISIBLE);
            exit.setVisibility(View.GONE);
            come_online.setText("登陆/注册");
        }
        flcontent.removeAllViews();
        flcontent.addView(view);
        personalListener();
    }



    private void personalListener() {
        //登陆或注册
        come_online.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(mActivity, PersonalCenterActivity.class);
                intent.putExtra("me",2);
                mActivity.startActivity(intent);

            }
        });
        iv_setting_person.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MyToastForBlue.makeText(mActivity, "如需更改信息，请先点击编辑右上角按钮！", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(mActivity, PersonalCenterActivity.class);
                intent.putExtra("me",2);
                mActivity.startActivityForResult(intent,8);


            }
        });


        //地址管理
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, ReceiveAddressList.class);
                mActivity.startActivity(intent);
            }
        });
        //广告加盟
        add_AD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, AdTogether.class);
                mActivity.startActivity(intent);
            }
        });
        //服务条款
        laws.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, Laws.class);
                mActivity.startActivity(intent);
            }
        });
        //建议反馈
        feed_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(mActivity, FeedBack.class);
                mActivity.startActivity(it);
            }
        });
        //关于
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(mActivity.getApplicationContext(), About_Activity.class);
                mActivity.startActivity(it);
            }
        });
        //联系我
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(mActivity.getApplicationContext(), ContactMe.class);
                mActivity.startActivity(it);
            }
        });
        //信息
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mActivity, SystemMessage.class);
                mActivity.startActivity(intent);
            }
        });
        //退出
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNormalDialog();
            }
        });
        //钱包
        ll_money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyToast.makeText(mActivity,"暂未开通",Toast.LENGTH_SHORT).show();
            }
        });
        //我帮助的
        ll_i_help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mActivity,HelpFenLei.class);
                intent.putExtra("location",7);
                mActivity.startActivity(intent);
            }
        });
        //帮助我的
        ll_help_i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(mActivity,HelpFenLei.class);
                intent.putExtra("location",6);
                mActivity.startActivity(intent);
            }
        });
    }
    private void showNormalDialog(){
        /* @setIcon 设置对话框图标
         * @setTitle 设置对话框标题
         * @setMessage 设置对话框消息提示
         * setXXX方法返回Dialog对象，因此可以链式设置属性
         */
        final android.support.v7.app.AlertDialog.Builder normalDialog =
                new android.support.v7.app.AlertDialog.Builder(mActivity);
        normalDialog.setIcon(R.drawable.exit);
        normalDialog.setTitle("离开");
        normalDialog.setMessage("确定要退出登陆吗?");
        normalDialog.setCancelable(false);
        normalDialog.setPositiveButton("确定",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //SpUtils.putBoolean(mActivity,"changeID",true);
                        BmobUser.logOut();   //清除缓存用户对象
                        // BmobUser currentUser = BmobUser.getCurrentUser(); // 现在的currentUser是null了
                        Intent intent =new Intent(mActivity,MainActivity.class);
                        mActivity.startActivity(intent);
                        mActivity.finish();
                        MyToast.makeText(mActivity,"退出成功",Toast.LENGTH_SHORT).show();
                    }
                });
        normalDialog.setNegativeButton("取消",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //do-nothing
                    }
                });
        // 显示
        normalDialog.show();
    }


}