package com.help.software.helpeachother.code.Activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

import com.help.software.helpeachother.R;
import com.help.software.helpeachother.code.Util.SpUtils.SpUtils;





/*
  1
* 第一个进入的页面，判断用户是否第一次进入
* 第一次进入，执行引导页；不是则跳过引导页，进入主页面
*
* 难点：动画
*
* */

public class SplashActivity extends AppCompatActivity  {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);

        //全屏显示图片
        if (Build.VERSION.SDK_INT >= 21) {//21表示5.0
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }

        initUI();
    }







    private void initUI() {
        RelativeLayout splash = findViewById(R.id.activity_splash);
        //旋转
        /*
        int pivotXType, float pivotXValue 设置旋转中心 0.5f 自身中点
        RELATIVE_TO_SELF：相对自身
        RELATIVE_TO_PARENT：相对父容器
        * */
        RotateAnimation rota = new RotateAnimation(0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rota.setDuration(1000);
        //动画停止时,停留在最后一帧,否则回到之前状态
        rota.setFillAfter(true);

        //缩放
        /*
         * fromXScale：开始前在x轴的大小
         * */
        ScaleAnimation scale = new ScaleAnimation(0, 1, 0, 1,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(600);
        scale.setFillAfter(true);

        //淡入淡出
        AlphaAnimation alpha = new AlphaAnimation(0, 1);
        alpha.setDuration(1500);
        alpha.setFillAfter(true);

        AnimationSet anima = new AnimationSet(true);
        anima.addAnimation(rota);
        anima.addAnimation(scale);
        anima.addAnimation(alpha);

        splash.setAnimation(anima);

        //设置监听器
        anima.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            //动画结束后执行
            @Override
            public void onAnimationEnd(Animation animation) {

                Boolean sp = SpUtils.getBoolean(getApplicationContext(), "FIRST_ENTER", true);

                if (sp) {
                    //第一次进入
                    new Thread() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } finally {
                                enter_newuser();
                            }
                        }
                    }.start();

                } else {
                    //不是第一次进入
                    new Thread() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(600);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } finally {
                                enter_home();

                            }
                        }

                    }.start();
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


    }

    private void enter_newuser() {

        //修改bollean值
        SpUtils.putBoolean(getApplicationContext(), "FIRST_ENTER", false);


        Intent it = new Intent(getApplicationContext(), GuideActivity.class);
        startActivity(it);
        finish();
    }

    private void enter_home() {


        Intent it = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(it);
        finish();
    }


}
