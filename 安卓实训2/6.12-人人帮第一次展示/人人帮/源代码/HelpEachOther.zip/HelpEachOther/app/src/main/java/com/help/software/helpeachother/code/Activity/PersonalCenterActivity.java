package com.help.software.helpeachother.code.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.githang.statusbar.StatusBarCompat;
import com.help.software.helpeachother.Bean._User;
import com.help.software.helpeachother.Bean.School;
import com.help.software.helpeachother.R;
import com.help.software.helpeachother.code.LoadingDialog.LoadingDialog;
import com.help.software.helpeachother.code.Util.MyToast;
import com.help.software.helpeachother.code.Util.MyToastForBlue;
import com.help.software.helpeachother.code.Util.getPhotoFromPhotoAlbum;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.UpdateListener;
import cn.bmob.v3.listener.UploadFileListener;

public class PersonalCenterActivity extends AppCompatActivity {

    private LinearLayout linearLayout;
    private TextView school, tel, sex, address, sign, name, tv_show;
    private ImageView iv_person;
    private ImageButton button_edit;
    private LinearLayout ll_school, ll_tel, ll_sex, ll_address, ll_sign;
    private boolean q = true;
    private EditText edit_text, edit_text1;
    private int yourChoice;
    private Handler handler;
    private LoadingDialog loadingDialog;
    private String[] schoollist;
    private Mycityy mycity;
    private String id;
    private _User userInfo;
    private CityChooseDialog1 cityChooseDialog;
    private ListView show_city;

    private School schools;
    private ArrayAdapter Myadapter;

    private SearchView main_searchview;

    public static final int TAKE_PHOTO = 1;

    public static final int CHOOSE_PHOTO = 2;

    public static final int CUT_PHOTO = 3;

    private _User newUser;

    private BmobFile bmobFile;

    private File cameraSavePath;//拍照照片路径
    private Uri uri;//照片资源

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_personal_centerll);
        StatusBarCompat.setStatusBarColor(this, Color.parseColor("#FF1A92E7"), false);


        // android 7.0系统解决拍照的问题
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            builder.detectFileUriExposure();
        }

        cameraSavePath = new File(Environment.getExternalStorageDirectory().getPath()
                + "/" + System.currentTimeMillis() + ".jpg");

        newUser = new _User();

        linearLayout = findViewById(R.id.personalL);
        school = findViewById(R.id.tv_school);
        school = findViewById(R.id.tv_school);
        tel = findViewById(R.id.tv_tel);
        sex = findViewById(R.id.tv_sex);
        address = findViewById(R.id.tv_address);
        sign = findViewById(R.id.tv_sign);
        name = findViewById(R.id.tv_name);
        iv_person = linearLayout.findViewById(R.id.iv_persons);
        button_edit = linearLayout.findViewById(R.id.ib_editt);
        ll_school = findViewById(R.id.ll_school);
        ll_tel = findViewById(R.id.ll_tel);
        ll_sex = findViewById(R.id.ll_sex);
        ll_address = findViewById(R.id.ll_address);
        ll_sign = findViewById(R.id.ll_sign);

        mycity = new Mycityy();

        userInfo = BmobUser.getCurrentUser(_User.class);

        schools = new School();
        Myadapter = new ArrayAdapter(PersonalCenterActivity.this, android.R.layout.simple_list_item_1, schools.getSchool());

        if (userInfo != null) {
            Intent ity = getIntent();
            int i = ity.getIntExtra("num", 0);
            Intent me = getIntent();
            int m = me.getIntExtra("me", 2);
            if (i == 1 || m == 2) {
                id = userInfo.getUsername();
                button_edit.setVisibility(View.VISIBLE);
            } else {
                id = ity.getStringExtra("id");
                button_edit.setVisibility(View.GONE);
            }
            //获取网络数据
            GetDataFromNet();

            //点击监听配置
            OpenOnlisten();

            //设置控件单击响应
            SetClick(false);
            //监听编辑按钮变化
            button_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (q) {
                        schoollist = null;
                        schoollist = schools.getSchool();

                        SetClick(true);
                        MyToastForBlue.makeText(PersonalCenterActivity.this, "已进入编辑页面，单击即可编辑", Toast.LENGTH_LONG).show();
                        button_edit.setBackgroundResource(R.drawable.finish);
                        q = !q;
                    } else

                    {
                        SetClick(false);
                        button_edit.setBackgroundResource(R.drawable.edit);
                        //发送数据至网络以更新
                        OpenNetworkConnect();
                        q = !q;
                    }
                }
            });
            handler = new Handler() {
                @Override
                public void handleMessage(Message msg) {// handler接收到消息后就会执行此方法
                    if (msg.what == 1) {
                        MyToastForBlue.makeText(PersonalCenterActivity.this,
                                "网络拥堵，请重新登录后再试！", Toast.LENGTH_SHORT).show();
                        loadingDialog.closeLoadingDialog(loadingDialog.loadingDialog);// 关闭ProgressDialog
                    } else {
                        loadingDialog.closeLoadingDialog(loadingDialog.loadingDialog);// 关闭ProgressDialog
                    }
                }
            };
        } else

        {
            MyToastForBlue.makeText(PersonalCenterActivity.this, "未登陆！", Toast.LENGTH_SHORT).show();
        }

    }

    //开启网络连接准备上传数据
    public void OpenNetworkConnect() {
        //开启progressDialog
        loadingDialog = new LoadingDialog();
        loadingDialog.startLoadingDialog(PersonalCenterActivity.this, "加载中...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                PutIntnet();
            }
        }).start();

    }

    public void back(View view) {
        finish();
    }

    //上传网络数据
    private void PutIntnet() {
        newUser.setMyname(name.getText().toString());
        newUser.setSchool(school.getText().toString());
        newUser.setSex(sex.getText().toString());
        newUser.setDes(sign.getText().toString());
        newUser.setMyaddress(address.getText().toString());
        newUser.setMytel(tel.getText().toString());

        BmobUser bmobUser = BmobUser.getCurrentUser(_User.class);
        newUser.update(bmobUser.getObjectId(), new UpdateListener() {
            @Override
            public void done(BmobException e) {
                if (e == null) {

                    handler.sendEmptyMessage(0);
                    MyToastForBlue.makeText(PersonalCenterActivity.this, "信息更改成功", Toast.LENGTH_LONG);
                } else {

                    Log.e("cuowu", e.toString());
                    Message message = new Message();
                    message.what = 1;
                    handler.sendMessage(message);
                }
            }
        });
    }

    //开启与关闭点击
    private void SetClick(boolean b) {
        if (b) {
            ll_school.setClickable(true);
            iv_person.setClickable(true);
            name.setClickable(true);
            ll_tel.setClickable(true);
            ll_sex.setClickable(true);
            ll_sign.setClickable(true);
            ll_address.setClickable(true);
        } else {

            MyToastForBlue.makeText(PersonalCenterActivity.this, "如需更改信息，请先点击编辑右上角按钮！", Toast.LENGTH_SHORT).show();
            ll_school.setClickable(false);
            iv_person.setClickable(false);
            name.setClickable(false);
            ll_tel.setClickable(false);
            ll_sex.setClickable(false);
            ll_sign.setClickable(false);
            ll_address.setClickable(false);
        }
    }

    //自定义通用提示框
    private void showCustomizeDialog(String des, final TextView textView) {
        TextView text = new TextView(PersonalCenterActivity.this);
        text.setText(des);
        text.setTextSize(16);
        text.setPadding(0, 10, 0, 15);
        text.setGravity(Gravity.CENTER);
        AlertDialog.Builder customizeDialog = new AlertDialog.Builder(PersonalCenterActivity.this);
        final View dialogView = LayoutInflater.from(PersonalCenterActivity.this).inflate(R.layout.dialog_customize, null);
        edit_text = dialogView.findViewById(R.id.edit_text);
        edit_text.setText(textView.getText());
        edit_text.setSelection(textView.length());//将光标移至文字末尾
        customizeDialog.setCustomTitle(text);
        customizeDialog.setView(dialogView);
        customizeDialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //获取EditView中输入内容
                if (edit_text.getText().length() != 0 | textView.getText().equals(edit_text.getText())) {
                    textView.setText(edit_text.getText());
                } else {
                    MyToastForBlue.makeText(PersonalCenterActivity.this, "信息未更改", Toast.LENGTH_LONG).show();
                }
            }
        });
        customizeDialog.show();
    }


    //性别选择框
    private void showSexDialog() {
        TextView text = new TextView(PersonalCenterActivity.this);
        text.setTextSize(16);
        text.setText("选择性别");
        text.setPadding(0, 40, 0, 15);
        text.setGravity(Gravity.CENTER);
        final String[] items = {"男", "女", "保密"};
        yourChoice = 0;
        AlertDialog.Builder singleChoiceDialog = new AlertDialog.Builder(PersonalCenterActivity.this);
        singleChoiceDialog.setCustomTitle(text);
        //第二个参数是默认选项 此处设置为0
        singleChoiceDialog.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                yourChoice = which;
            }
        });
        singleChoiceDialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sex.setText(items[yourChoice]);
            }
        });
        singleChoiceDialog.show();
    }




    //开启点击监听
    private void OpenOnlisten() {
        iv_person.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String title = "选择获取图片方式";
                String[] items = new String[]{"拍照", "相册"};

                new AlertDialog.Builder(PersonalCenterActivity.this).setTitle(title).setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                        switch (which) {
                            case 0:
                                //选择拍照
                                pickImageFromCamera();
                                break;
                            case 1:
                                //选择相册
                                pickImageFromAlbum();
                                break;
                            default:
                                break;
                        }
                    }
                }).show();

                MyToastForBlue.makeText(PersonalCenterActivity.this, "暂未支持修改头像", Toast.LENGTH_LONG).show();
            }
        });
        name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomizeDialog("请输入您的昵称", name);

            }
        });

        ll_school.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cityChooseDialog = new CityChooseDialog1();
                cityChooseDialog.startLoadingDialog(PersonalCenterActivity.this);

            }

        });

        ll_tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomizeDialog("输入您的电话:", tel);
            }
        });

        ll_sex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSexDialog();
            }
        });
        ll_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomizeDialog("输入您的住址:", address);
            }
        });
        ll_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomizeDialog("输入您的个性签名:", sign);
            }
        });

    }


    //拍照
    public void pickImageFromCamera() {

        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED)) {

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            uri = FileProvider.getUriForFile(PersonalCenterActivity.this, "com.help.software.helpeachother.fileprovider", cameraSavePath);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);

            startActivityForResult(intent, TAKE_PHOTO);
        } else {
            Toast.makeText(this, "请确认已经插入SD卡", Toast.LENGTH_SHORT).show();
        }


    }

    //从相册获取图片
    public void pickImageFromAlbum() {

        MyToast.makeText(PersonalCenterActivity.this,"注意请从相机拍照后的相册中选取！",Toast.LENGTH_SHORT).show();


            Intent picIntent = new Intent(Intent.ACTION_PICK, null);
            picIntent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");


        final PackageManager packageManager = this.getPackageManager();
        final List<ResolveInfo> list = packageManager.queryIntentActivities(picIntent, PackageManager.MATCH_DEFAULT_ONLY);
        //  当存在可用的程序才调用，否则会报错
        if (list.size() > 0) {
            startActivityForResult(picIntent, CHOOSE_PHOTO);
        } else {
            Log.e("zjq", "no application with ACTION_GET_CONTENT");

        }
        return;
    }


    //上传图片到表中
    private void upload(String imgpath) {

        //开启等待
        loadingDialog = new LoadingDialog();
        loadingDialog.startLoadingDialog(PersonalCenterActivity.this, "上传中...");
        bmobFile = new BmobFile(new File(imgpath));
        bmobFile.uploadblock(new UploadFileListener() {
            @Override
            public void done(BmobException e) {
                if (e == null) {
                    newUser.setAvatar(bmobFile);//该用户的头像图片
                    newUser.saveObservable();

                    //bmobFile.getFileUrl()--返回的上传文件的完整地址
                    Log.w("zjq", bmobFile.getFileUrl());
                    loadingDialog.closeLoadingDialog(loadingDialog.loadingDialog);
                    Toast.makeText(PersonalCenterActivity.this, "上传文件成功!", Toast.LENGTH_SHORT).show();
                } else {
                    Log.w("zjq", e.getMessage());

                    MyToast.makeText(PersonalCenterActivity.this, "上传文件失败,请重新上传！", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }


    /**
     * 根据路径获取bitmap（压缩后）
     *
     * @param srcPath 图片路径
     * @param width   最大宽（压缩完可能会大于这个，这边只是作为大概限制，避免内存溢出）
     * @param height  最大高（压缩完可能会大于这个，这边只是作为大概限制，避免内存溢出）
     * @param size    图片大小，单位kb
     * @return 返回压缩后的bitmap
     */
    public static Bitmap getCompressBitmap(String srcPath, float width, float height, int size) {

        BitmapFactory.Options newOpts = new BitmapFactory.Options();
        // 开始读入图片，此时把options.inJustDecodeBounds 设回true了
        newOpts.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(srcPath, newOpts);

        newOpts.inJustDecodeBounds = false;
        int w = newOpts.outWidth;
        int h = newOpts.outHeight;
        int scaleW = (int) (w / width);
        int scaleH = (int) (h / height);
        int scale = scaleW < scaleH ? scaleH : scaleW;
        if (scale <= 1) {
            scale = 1;
        }
        newOpts.inSampleSize = scale;// 设置缩放比例
        // 重新读入图片，注意此时已经把options.inJustDecodeBounds 设回false了

        Bitmap bitmap = BitmapFactory.decodeFile(srcPath, newOpts);

        // 压缩好比例大小后再进行质量压缩
        return compressImage(bitmap, size);
    }


    /**
     * 图片质量压缩
     *
     * @param image 传入的bitmap
     * @param size  压缩到多大，单位kb
     * @return 返回压缩完的bitmap
     */
    public static Bitmap compressImage(Bitmap image, int size) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // 质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
        int options = 100;
        image.compress(Bitmap.CompressFormat.JPEG, options, baos);
        // 循环判断如果压缩后图片是否大于size,大于继续压缩
        while (baos.toByteArray().length / 1024 > size) {
            // 重置baos即清空baos
            baos.reset();
            // 每次都减少10
            options -= 10;
            // 这里压缩options%，把压缩后的数据存放到baos中
            image.compress(Bitmap.CompressFormat.JPEG, options, baos);
        }
        // 把压缩后的数据baos存放到ByteArrayInputStream中
        ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());
        // 把ByteArrayInputStream数据生成图片
        Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);

        if (bitmap!=null){
            return bitmap;
        }else {

            return image;
        }

    }



    /**
     * 获取图片的旋转角度。
     * 只能通过原始文件获取，如果已经进行过bitmap操作无法获取。
     */
    private static int getRotateDegree(String path) {
        int result = 0;
        try {
            ExifInterface exif = new ExifInterface(path);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    result = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    result = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    result = 270;
                    break;
            }
        } catch (IOException ignore) {
            return 0;
        }
        return result;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            switch (requestCode) {

                case TAKE_PHOTO: {

                    // 先记录图片旋转角度
                    int degree = getRotateDegree(cameraSavePath.getPath());
                    Matrix matrix = new Matrix();
                    matrix.postRotate(degree);

                    //将图片交给getCompressBitmap压缩并返回bitmap
                    Bitmap bitmap = getCompressBitmap(cameraSavePath.getPath(), 300, 400, 200);
                    //用之前记录的旋转角度纠正 歪了的图片
                    Bitmap outBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
                    // 释放原来的bitmap
                    bitmap.recycle();

                    //把Bitmap 对象转换为 File类对象
                    File file = new File(cameraSavePath.getPath());//将要保存图片的路径
                    BufferedOutputStream bos = null;
                    try {

                        bos = new BufferedOutputStream(new FileOutputStream(file));
                        outBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                        bos.flush();
                        bos.close();

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                    Glide.with(this).load(file).into(iv_person);

                    //file文件上传
                    upload(file.getPath());
                }
                break;
                case CHOOSE_PHOTO: {


                    //工具类 获取相册返回的uri
                    String photoPath = getPhotoFromPhotoAlbum.getRealPathFromUri(getApplicationContext(), data.getData());

                    // 先记录图片旋转角度
                    int degree1 = getRotateDegree(photoPath);
                    Matrix matrix1 = new Matrix();
                    matrix1.postRotate(degree1);


                    Bitmap bitmap1 = getCompressBitmap(photoPath, 200, 300, 150);

                    Bitmap outBitmap1 = Bitmap.createBitmap(bitmap1, 0, 0, bitmap1.getWidth(), bitmap1.getHeight(), matrix1, false);

                    //bitmap1.recycle();

                    File file1 = new File(photoPath);
                    BufferedOutputStream bos1 = null;
                    try {

                        bos1 = new BufferedOutputStream(new FileOutputStream(file1));
                        outBitmap1.compress(Bitmap.CompressFormat.JPEG, 100, bos1);
                        bos1.flush();
                        bos1.close();

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    Glide.with(PersonalCenterActivity.this).load(file1.getPath()).into(iv_person);

                    //file文件上传
                    upload(file1.getPath());

                }
                break;
                case CUT_PHOTO:
//                    String photoPath = null;
//
//                    photoPath = String.valueOf( cameraSavePath );
//                    photoPath = uri.getEncodedPath();

                    //file =new BmobFile(mFile);
                    //   Glide.with(this).load(Uri.fromFile(mFile)).into(iv_person);


                    break;


            }
        }

    }

    /**
     * 打开系统图片裁剪功能
     */
    private void startPhotoZoom(Uri uri) {

        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", true);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 300);
        intent.putExtra("outputY", 300);
        intent.putExtra("scale", true);

        intent.putExtra("noFaceDetection", true);
        startActivityForResult(intent, CUT_PHOTO);

    }

    private void setPicToView(Intent data) {
        Bundle bundle = data.getExtras();
      /*  if (bundle != null) {

            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);


//            //这里也可以做文件上传
          //  Bitmap bm= BitmapFactory.decodeFile(picturePath);
           // mBitmap = bundle.getParcelable("data");
//            ivHead.setImageBitmap(mBitmap);


           // iv_person.setImageBitmap(bm);
//            if (picturePath != null) {
//                path = picturePath;
//            }
//        }
            if (mFile != null) {
                path = mFile.getPath();
                Glide.with(PersonalCenterActivity.this).load(path).into(iv_person);

            }

            Toast.makeText(PersonalCenterActivity.this, "path:" + path, Toast.LENGTH_SHORT).show();

            final BmobFile bmobFile = new BmobFile(new File(path));


            //Bmob这个上传文件的貌似不成功..........................
            bmobFile.uploadblock(new UploadFileListener() {

                @Override
                public void done(BmobException e) {
                *//*if (e == null) {
                    Toast.makeText(PersonalCenterActivity.this, "pic is success", Toast.LENGTH_SHORT).show();
                    _User myUser = _User.getCurrentUser(_User.class);
                    //得到上传的图片地址
                    String fileUrl = bmobFile.getFileUrl();
                    myUser.setAvatar(fileUrl);
                    //更新图片地址
                    myUser.update(_User.getObjectId(), new UpdateListener() {
                        @Override
                        public void done(BmobException e) {
                            if (e == null) {
                                Toast.makeText(PersonalCenterActivity.this, "update", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                }*//*
                }
            });
        }*/


        //  photoPath = String.valueOf(cameraSavePath);
    }

    //获取网络数据
    private void GetDataFromNet() {
        userInfo = BmobUser.getCurrentUser(_User.class);
        //开启progressDialog
        loadingDialog = new LoadingDialog();
        loadingDialog.startLoadingDialog(PersonalCenterActivity.this, "加载中...");

        new Thread(new Runnable() {
            @Override
            public void run() {
                if (userInfo != null) {
                    BmobQuery<_User> query = new BmobQuery<>();
                    query.addWhereEqualTo("username", id);
                    //先缓存再网络获取数据
                    query.findObjects(new FindListener<_User>() {
                        @Override
                        public void done(List<_User> object, BmobException e) {
                            if (e == null) {
                                _User user = new _User();
                                user = object.get(0);

                                //设置头像
                                if (user.getAvatar() != null) {
                                    Log.e("zjq", "更新头像啦");
                                    Glide.with(PersonalCenterActivity.this).load(user.getAvatar().getFileUrl()).into(iv_person);
                                } else {
                                    MyToast.makeText(PersonalCenterActivity.this, "您未设置头像，为您设置了默认头像", Toast.LENGTH_SHORT).show();
                                }


                                if (user.getMyname() == null) {
                                    name.setText("未设置昵称");
                                } else {
                                    name.setText(user.getMyname());
                                }
                                if (user.getSchool() == null) {
                                    school.setText("未设置");
                                } else {
                                    school.setText(user.getSchool());
                                }
                                if (user.getSex() == null) {
                                    sex.setText("未设置");
                                } else {
                                    sex.setText(user.getSex());
                                }
                                if (user.getMyaddress() == null) {
                                    address.setText("未设置");
                                } else {
                                    address.setText(user.getMyaddress());
                                }
                                if (user.getDes() == null) {
                                    sign.setText("未设置");
                                } else {
                                    sign.setText(user.getDes());
                                }
                                if (user.getMytel() == null) {
                                    tel.setText(user.getUsername());
                                } else {
                                    tel.setText(user.getMytel());
                                }
                                handler.sendEmptyMessage(0);
                            } else {
                                Message message = new Message();
                                message.what = 1;
                                handler.sendMessage(message);
                            }
                        }
                    });
                } else {
                    handler.sendEmptyMessage(0);
                }
            }
        }).start();
    }

    class Mycityy extends BaseAdapter {


        @Override
        public int getCount() {
            return schoollist.length;
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            View view = View.inflate(PersonalCenterActivity.this, R.layout.item_city_list, null);
            tv_show = view.findViewById(R.id.tv_item);
            //o==3县区级
            if (position == 0) {
                tv_show.setText(schoollist[position]);
                tv_show.setTextColor(Color.parseColor("#ff5f1a"));
            } else {
                tv_show.setText(schoollist[position]);
            }
            return view;
        }


    }


    //学校选择提示框
    public class CityChooseDialog1 {
        public Dialog loadingDialog;

        public Dialog startLoadingDialog(Context context) {

            LayoutInflater inflater = LayoutInflater.from(context);
            View v = inflater.inflate(R.layout.address_citychoose, null);// 得到加载view
            LinearLayout layout = v.findViewById(R.id.jjj);// 加载布局

            show_city = v.findViewById(R.id.lv_show_city);

            loadingDialog = new Dialog(context);// 创建自定义样式dialog
            loadingDialog.setCancelable(true); // 是否可以按“返回键”消失
            loadingDialog.setCanceledOnTouchOutside(false); // 点击加载框以外的区域

            loadingDialog.setContentView(layout, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));// 设置布局

            /*show_city.setAdapter( mycity );*/

            show_city.setAdapter(Myadapter);
            show_city.setTextFilterEnabled(true);

            //00
            main_searchview = v.findViewById(R.id.main_searchview);

            main_searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() // 设置搜索文本监听
            {
                @Override
                public boolean onQueryTextSubmit(String query) {//搜索时触发事件
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {//搜索时根据文本框动态改变搜索内容

                    if (!TextUtils.isEmpty(newText)) {

                        // main_listview.setFilterText( newText ); 有黑框
                        //无黑框
                        Myadapter.getFilter().filter(newText);


                    } else {
                        show_city.clearTextFilter();
                        show_city.clearChoices();
                        Myadapter.getFilter().filter("");

                    }
                    return true;
                }
            });

            show_city.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    String s = (String) parent.getItemAtPosition(position);

                    if ("请选择学校（按字母顺序排列）".equals(s)) {

                        MyToastForBlue.makeText(PersonalCenterActivity.this, "请选择您的学校", Toast.LENGTH_SHORT).show();

                    } else {

                        school.setText(s);
                        cityChooseDialog.closeLoadingDialog(cityChooseDialog.loadingDialog);

                    }
                }
            });

            /**
             *将显示Dialog的方法封装在这里面
             */
            Window window = loadingDialog.getWindow();
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setGravity(Gravity.CENTER);
            window.setAttributes(lp);
            loadingDialog.show();

            return loadingDialog;
        }

        public void closeLoadingDialog(Dialog mDialogUtils) {
            if (mDialogUtils != null && mDialogUtils.isShowing()) {
                mDialogUtils.dismiss();
            }
        }


    }

}
