package com.help.software.helpeachother.ViewHolder;

import android.widget.TextView;

/*
 * 项目名:   PullLoadMore
 * 包名:     com.john.software.pullloadmore.ViewHolder
 * 文件名:   ViewHolder
 * 创建者:   software.John
 * 创建时间: 2019/5/8 20:29
 * 描述:      TODO
 */
public class ViewHolder {
        public TextView sex;
        public TextView school;
        public TextView name;
    }

