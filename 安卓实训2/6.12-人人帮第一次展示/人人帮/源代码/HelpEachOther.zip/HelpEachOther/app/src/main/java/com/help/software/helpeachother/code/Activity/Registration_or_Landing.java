package com.help.software.helpeachother.code.Activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.githang.statusbar.StatusBarCompat;
import com.help.software.helpeachother.Bean._User;
import com.help.software.helpeachother.R;
import com.help.software.helpeachother.code.LoadingDialog.LoadingDialog;
import com.help.software.helpeachother.code.Util.MyToast;
import com.help.software.helpeachother.code.Util.SpUtils.FirstCome;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;


/*
 * 登录界面
 *
 *
 * */

public class Registration_or_Landing extends AppCompatActivity {
    private EditText telephone, password;
    private ImageView show_password, back;
    private TextView forget_password;
    private String tel, pas;
    private int a = 0;
    private LoadingDialog loadingDialog;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_or_landing);

        //改变状态栏颜色()
        StatusBarCompat.setStatusBarColor(this, Color.parseColor("#f1f0f0"), false);

        telephone = findViewById(R.id.et_landing_telephone);
        password = findViewById(R.id.et_landing_password);
        back = findViewById(R.id.iv_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        show_password = findViewById(R.id.iv_landing_show_password);
        forget_password = findViewById(R.id.forget_password);
        show_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (a == 0) {
                    a = 1;
                    show_password.setImageResource(R.drawable.landing_no_show);
                    //隐藏密码
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    a = 0;
                    show_password.setImageResource(R.drawable.landing_show);
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        //忘记密码
        forget_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), Registration.class);
                it.putExtra("forgetpas", 1);
                startActivity(it);
            }
        });

        handler = new Handler() {
            @Override
            public void handleMessage(final Message msg) {
                if (msg.what == 1) {
                    MyToast.makeText(Registration_or_Landing.this, "账号或密码错误", Toast.LENGTH_LONG).show();
                    loadingDialog.closeLoadingDialog(loadingDialog.loadingDialog);
                }
            }
        };
    }


    //登陆
    public void landing(View view) {
        tel = telephone.getText().toString();
        pas = password.getText().toString();

        //手机号密码规则
        if (tel.length() == 11 && pas.length() != 0) {
            //开启等待
            loadingDialog = new LoadingDialog();
            loadingDialog.startLoadingDialog(Registration_or_Landing.this, "加载中...");

            new Thread() {
                @Override
                public void run() {

                    BmobUser bu2 = new BmobUser();
                    bu2.setUsername(tel);
                    bu2.setPassword(pas);
                    bu2.login(new SaveListener<_User>() {
                        @Override
                        public void done(_User user, BmobException e) {
                            if (e == null) {
                                MyToast.makeText(Registration_or_Landing.this, "登陆成功，即将重新打开", Toast.LENGTH_SHORT).show();
                                loadingDialog.closeLoadingDialog(loadingDialog.loadingDialog);
                                Intent intent = new Intent(Registration_or_Landing.this, MainActivity.class);
                                startActivity(intent);
                                FirstCome.first = true;
                                finish();

                            } else {
                                Message message = new Message();
                                message.what = 1;
                                handler.sendMessage(message);
                            }
                        }
                    });
                }
            }.start();
        } else {
            MyToast.makeText(Registration_or_Landing.this, "账号或密码格式错误", Toast.LENGTH_LONG).show();
        }
    }

    //注册
    public void registration(View view) {
        Intent it = new Intent(getApplicationContext(), Registration.class);
        startActivity(it);
    }
}
