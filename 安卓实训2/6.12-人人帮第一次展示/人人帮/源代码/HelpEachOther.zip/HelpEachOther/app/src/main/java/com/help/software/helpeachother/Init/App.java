package com.help.software.helpeachother.Init;

import android.app.Application;

import com.baidu.mapapi.SDKInitializer;

import cn.bmob.v3.Bmob;


public class App extends Application {
    @Override
    public void onCreate() {
       // Bmob.initialize(this, "b3646f4197dc70a1bb71fccf86025339");

        Bmob.initialize(this, "f947f3eb9b7110436a61731f146519a1");

        //百度地图
        SDKInitializer.initialize(this);

    }

}
