package com.help.software.helpeachother.code.Util.SpUtils;

/**
 * Created by Administrator on 2018/1/30.
 */

public class FirstCome {
    public static boolean first=true;
    public static boolean firstperson=false;
    public static boolean firsta=true;
    public static boolean leftenter=false;
}
