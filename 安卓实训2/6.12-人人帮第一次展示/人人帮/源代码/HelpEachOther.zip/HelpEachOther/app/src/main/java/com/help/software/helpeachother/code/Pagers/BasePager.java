package com.help.software.helpeachother.code.Pagers;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.help.software.helpeachother.Bean._User;
import com.help.software.helpeachother.code.Activity.MainActivity;
import com.help.software.helpeachother.R;
import com.help.software.helpeachother.code.Fragment.LeftMenuFragMent;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;

public class BasePager {

    public RelativeLayout relativeLayout;
    public Activity mActivity;
    public TextView tvTitle;
    public TextView tvTitlecenter;
    public ImageView imageButton;
    public FrameLayout flcontent;
    public View rootview;



    //头像
    private BmobFile bmobFile;




    public BasePager(Activity mActivity) {

        this.mActivity = mActivity;

        rootview = initView();

    }

    public View initView() {

        View view = View.inflate(mActivity, R.layout.base_layout, null);
        tvTitle =view.findViewById(R.id.tv_title);
        tvTitlecenter = view.findViewById(R.id.center);
        imageButton = view.findViewById(R.id.btn_menu);


        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                MainActivity mainUI = (MainActivity) mActivity;
                mainUI.getSlidingMenu().toggle();
            }
        });


        relativeLayout =  view.findViewById(R.id.title_bar);
        flcontent = view.findViewById(R.id.fl_content);



        return view;
    }

    public void initData() {









    }


}
