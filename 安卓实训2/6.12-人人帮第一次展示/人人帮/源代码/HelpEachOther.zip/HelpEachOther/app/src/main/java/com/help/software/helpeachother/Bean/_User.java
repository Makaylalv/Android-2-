package com.help.software.helpeachother.Bean;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;


public class _User extends BmobUser {

    private String sex;
    private String myname;
    private String mytel;
    private String school;
    private String myaddress;
    private String des;
    private Integer money;
    private BmobFile avatar;


    @Override
    public void setTableName(String tableName) {
        super.setTableName(tableName);
    }

    public void setAvatar(BmobFile avatar) {
        this.avatar = avatar;
    }

    public BmobFile getAvatar() {

        return avatar;

    }

    public String getSex() {
        return this.sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSchool() {
        return this.school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMyaddress() {
        return myaddress;
    }

    public void setMyaddress(String myaddress) {
        this.myaddress = myaddress;
    }

    public String getDes() {
        return this.des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getMyname() {
        return this.myname;
    }

    public void setMyname(String myname) {
        this.myname = myname;
    }

    public String getMytel() {
        return this.mytel;
    }

    public void setMytel(String mytel) {
        this.mytel = mytel;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }
}

