package com.help.software.helpeachother.code.Util.SpUtils;

import android.content.Context;
import android.content.SharedPreferences;



public class SpUtils {

    private static SharedPreferences sp;

    //修改SharedPreferences值
    public static void putBoolean(Context context, String key, Boolean values){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
        //edit
        sp.edit().putBoolean(key,values).commit();
    }

    //判断是否第一次进入
    public static Boolean getBoolean(Context context,String key,Boolean defValue){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
       return sp.getBoolean(key,defValue);
    }





    public static void putString(Context context, String key, String values){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
        sp.edit().putString(key,values).commit();
    }
    public static String getString(Context context,String key,String defValue){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
        return sp.getString(key,defValue);
    }
    public static void putInt(Context context, String key, int values){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
        sp.edit().putInt(key,values).commit();
    }
    public static int getInt(Context context,String key,int defValue){
        if (sp==null){
            sp=context.getSharedPreferences("config",Context.MODE_PRIVATE);
        }
        return sp.getInt(key,defValue);
    }
}
