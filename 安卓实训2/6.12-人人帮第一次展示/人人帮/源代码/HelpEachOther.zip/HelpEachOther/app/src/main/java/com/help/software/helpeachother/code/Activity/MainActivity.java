package com.help.software.helpeachother.code.Activity;

import android.Manifest;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.Toast;

import com.help.software.helpeachother.Bean.Address;
import com.help.software.helpeachother.Bean._User;
import com.help.software.helpeachother.R;
import com.help.software.helpeachother.Sliding.SlidingMenu;
import com.help.software.helpeachother.Sliding.app.SlidingFragmentActivity;
import com.help.software.helpeachother.code.Fragment.LeftMenuFragMent;
import com.help.software.helpeachother.code.Fragment.MainFragment;
import com.help.software.helpeachother.code.Util.MyToast;

import java.util.List;

import cn.bmob.v3.BmobUser;
import pub.devrel.easypermissions.EasyPermissions;


/*
* 首页 主页面
*
* 判断用户是否登录
* 登录 在本页面
* 未登录 去登录页面
*
*难点： 侧滑菜单（？）
* */

public class MainActivity extends SlidingFragmentActivity implements EasyPermissions.PermissionCallbacks{
   private long firstTime=0;
   private SlidingMenu slidingMenu;
   private int a=0;
   Address address;
   private Handler handler;

    private String[] permissions = {
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,

    };



    //获取权限
    private void getPermission() {

        if (EasyPermissions.hasPermissions(this, permissions)) {
//            //已经打开权限
//
//            MyToast.makeText(this, "已经申请相关权限", Toast.LENGTH_SHORT).show();

        } else {

            //没有打开相关权限、申请权限
            EasyPermissions.requestPermissions(this, "需要获取相关权限", 1, permissions);

        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //框架要求必须这么写
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    //成功打开权限
    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

        MyToast.makeText(this, "相关权限获取成功", Toast.LENGTH_SHORT).show();
    }

    //用户未同意权限
    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {


        MyToast.makeText(this, "请在应用设置中开启相关权限，否则部分功能无法使用", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //侧滑
        setBehindContentView(R.layout.left_menu_layout);
        setContentView(R.layout.activity_main);

       _User user =BmobUser.getCurrentUser(_User.class);

       if(user !=null){
           MyToast.makeText(this,"欢迎您！"+ user.getMyname(),Toast.LENGTH_SHORT).show();

           getPermission();

       }else{
           MyToast.makeText(this,"未登录，即将打开登陆界面！", Toast.LENGTH_LONG).show();
           new Thread(){
               @Override
               public void run() {
                   try{
                       Thread.sleep(2000);
                       Message message=new Message();
                       message.what=0;
                       handler.sendMessage(message);
                   }catch (InterruptedException e){
                       e.printStackTrace();
                   }
               }
           }.start();
       }
        handler=new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what==0){
                    Intent intent=new Intent(MainActivity.this,Registration_or_Landing.class);
                    startActivity(intent);
                    finish();
                }
            }
        };




        //测量屏幕宽度
        WindowManager wm=this.getWindowManager();
        int with=wm.getDefaultDisplay().getWidth();

        slidingMenu=getSlidingMenu();
        //设置预留剩余屏幕宽度
        slidingMenu.setBehindOffset(with/3);
        //主屏幕全屏触摸
        slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        slidingMenu.setOnClosedListener(new SlidingMenu.OnClosedListener() {
            @Override
            public void onClosed() {
                a=0;
            }
        });
        //侧滑菜单监听
        slidingMenu.setOnOpenedListener(new SlidingMenu.OnOpenedListener() {
            @Override
            public void onOpened() {
                a=1;
            }
        });
        initFragMent();

    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {

        if(a==0){
            if(keyCode==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP){
                long secondeTime=System.currentTimeMillis();
                if(secondeTime-firstTime>1500){
                    MyToast.makeText(MainActivity.this,"再划一次退出！",Toast.LENGTH_LONG);
                    firstTime=secondeTime;
                    return true;
                }else{
                    System.exit(0);
                }
            }
            return super.onKeyUp(keyCode,event);
        }
       else slidingMenu.toggle();
        return false;
    }


    //FragmentTransaction可以在运行时添加，删除或替换Fragment，从而实现UI的动态变化。
    // Fragment Transaction由Fragment Manager的beginTransaction()方法创建，然后可以进行Fragment的添加，删除和替换，最后通过commit()方法提交修改。

    private void initFragMent(){
        FragmentManager fragment=getSupportFragmentManager();
        //开启事务
        FragmentTransaction transaction=fragment.beginTransaction();

                    //侧滑
        transaction.replace(R.id.left_menu_layout,new LeftMenuFragMent(),"LEFT_FRAGMENT");
        transaction.replace(R.id.activity_main,new MainFragment(),"MAIN_FRAGMENT");
        //提交事务
        transaction.commit();
    }
}

