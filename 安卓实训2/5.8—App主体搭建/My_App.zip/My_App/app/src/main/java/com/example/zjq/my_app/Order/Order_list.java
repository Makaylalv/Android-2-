package com.example.zjq.my_app.Order;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.zjq.my_app.R;

public class Order_list  extends Fragment{

    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState){
        View view=  inflater.inflate( R.layout.order_list,container,false );

        //更换 信息界面 内容

        return view;
    }

    public void onViewCreated(View view,
                              Bundle savedInstanceState){
        super.onViewCreated( view,savedInstanceState );


    }
}
