package com.example.zjq.my_app.HomePage.Rolling_picture.ViewPager_home;

import com.example.zjq.my_app.R;

public class Images  {
    public final static int[] imageArray =new int[]{
            R.drawable.l1,
            R.drawable.l2,
            R.drawable.l3,
            R.drawable.l4,
    };
}
