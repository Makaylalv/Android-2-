package com.example.zjq.my_app.Registration_Landing;



import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.zjq.my_app.Bean.User;
import com.example.zjq.my_app.R;
import com.mob.MobSDK;
import org.json.JSONException;
import org.json.JSONObject;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;
import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;


public class Registration extends AppCompatActivity {

    private EditText telephone;//电话号
    private TextView send;//获取验证码
    private Button yanzheng;//注册，验证
    private EditText yanzhengma;
    private EditText ps;


    private static String phone;
    private static String number;
    private static String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        telephone =findViewById(R.id.et_registration_telephone);
        send =  findViewById(R.id.tv_registration_yanzhengma);
        yanzheng=findViewById( R.id.btn_reg );
        yanzhengma=findViewById( R.id.et_registration_yanzhengma );
        ps=findViewById( R.id.et_registration_password );

        //mob
        MobSDK.init(Registration.this);
        send();
        Handler();
        yanzheng();

        //bmob
        Bmob.initialize(this, "f947f3eb9b7110436a61731f146519a1");

    }

    private void yanzheng() {
        yanzheng.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone = telephone.getText().toString();
                number= yanzhengma.getText().toString();
                //提交验证码验证
                if (TextUtils.isEmpty(phone))
                    Toast.makeText(Registration.this,"号码不能为空",Toast.LENGTH_SHORT).show();
                if (TextUtils.isEmpty(number))
                    Toast.makeText(Registration.this,"号码不能为空",Toast.LENGTH_SHORT).show();
                Log.i("1234",phone+","+number);
                SMSSDK.submitVerificationCode("86",phone,number);
            }
        } );
    }

    private void send() {
        send.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone = telephone.getText().toString();

                //获取验证码
                if (TextUtils.isEmpty(phone))
                    Toast.makeText(Registration.this,"号码不能为空",Toast.LENGTH_SHORT).show();
                Log.i("1234",phone.toString());
                SMSSDK.getVerificationCode("86",phone);
            }
        } );
    }

    private void Handler() {
        EventHandler handler = new EventHandler(){
            @Override
            public void afterEvent(int event, int result, Object data) {
                if (result == SMSSDK.RESULT_COMPLETE){

                    //回调完成
                    if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                        //提交验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                password=ps.getText().toString();

                                Toast.makeText(Registration.this,"验证成功",Toast.LENGTH_SHORT).show();
                                adduser();
                                finish();
                            }
                        });
                    }else if (event == SMSSDK.EVENT_GET_VOICE_VERIFICATION_CODE){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(Registration.this,"语音验证发送",Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE){
                        //获取验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(Registration.this,"验证码已发送",Toast.LENGTH_SHORT).show();
                            }
                        });
                    }else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES){
                        Log.i("test","test");
                    }
                }else{
                    ((Throwable)data).printStackTrace();
                    Throwable throwable = (Throwable) data;
                    throwable.printStackTrace();
                    Log.i("1234",throwable.toString());
                    try {
                        JSONObject obj = new JSONObject(throwable.getMessage());
                        final String des = obj.optString("detail");
                        if (!TextUtils.isEmpty(des)){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(Registration.this,des,Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        SMSSDK.registerEventHandler(handler);
    }

    private void adduser() {
        User p2 = new User();
        p2.setName(phone);
        p2.setAddress(password);
        p2.save(new SaveListener<String>() {
            @Override
            public void done(String objectId,BmobException e) {
                if(e==null){
                    Toast.makeText(Registration.this,"添加数据成功，返回objectId为："+objectId,Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(Registration.this,"创建数据失败：" + e.getMessage(),Toast.LENGTH_SHORT).show();

                }
            }
        });
    }


}
