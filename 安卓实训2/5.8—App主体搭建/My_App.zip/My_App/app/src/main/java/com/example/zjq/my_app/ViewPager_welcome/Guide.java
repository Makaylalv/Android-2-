package com.example.zjq.my_app.ViewPager_welcome;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.zjq.my_app.Fragment_tab.FragmentTab;
import com.example.zjq.my_app.R;

import java.util.ArrayList;
import java.util.List;

public class Guide extends Activity implements ViewPager.OnPageChangeListener{

    private ViewPager vp;
    private ViewPagerAdapter_main vpAdapter;
    private List<View>  views;

    private ImageView[] dots;
    private int[] ids={R.id.point1,R.id.point2,R.id.point3};

    private Button start_btn;



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.layout_viewpager_guide );

        //全屏
        Top();

        //引导页加载
        initViews();

        //下面导航的改变
        initDots();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void Top() {
        View decorView = getWindow().getDecorView();
        int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        decorView.setSystemUiVisibility(option);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
    }

    private  void initViews(){
        LayoutInflater inflater= LayoutInflater.from( this );
        views=new ArrayList<View>(  );
        views.add( inflater.inflate( R.layout.one_guide,null) );
        views.add( inflater.inflate( R.layout.two_guide,null) );
        views.add( inflater.inflate( R.layout.three_guide,null) );

        vpAdapter=new ViewPagerAdapter_main(views,this);
        vp=findViewById( R.id.viewpager );
        vp.setAdapter( vpAdapter );
        start_btn=views.get( 2 ).findViewById( R.id.btn_start );
        start_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent( Guide.this, FragmentTab.class );
                startActivity( intent );
                finish();
            }
        } );
        //?
        vp.setOnPageChangeListener( this );
    }
    private void initDots(){
        dots=new  ImageView[views.size()];
        for (int i=0;i<views.size();i++){
            dots[i]=findViewById( ids[i] );
        }
    }

    //页面被滑动调用
    @Override
    public void onPageScrolled(int i, float v, int i1) {

    }

    //当前新的页面被选中时候调用,更改 导航点 的状态
    @Override
    public void onPageSelected(int i) {
        for (int j=0;j<ids.length;j++){

            //选中时
            if (i==j){
                dots[j].setImageResource( R.drawable.login_point_selected );
            }else {
                dots[j].setImageResource( R.drawable.login_point );
            }
        }

    }

    //滑动状态改变的时候调用
    @Override
    public void onPageScrollStateChanged(int i) {

    }
}
