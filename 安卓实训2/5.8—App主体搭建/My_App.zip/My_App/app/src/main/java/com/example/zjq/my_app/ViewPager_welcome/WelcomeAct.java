package com.example.zjq.my_app.ViewPager_welcome;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.widget.Toast;


import com.example.zjq.my_app.Fragment_tab.FragmentTab;
import com.example.zjq.my_app.R;



public class WelcomeAct extends Activity {
    private static final int TIME=2000;

    private boolean isFirstIn=false;
    private static final int GO_HOME=1;
    private static final int GO_GUIDE=2;
    private Handler handler;

    private Handler mHandler=new Handler(  ){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case GO_HOME:
                {
                    Intent intent=new Intent( WelcomeAct.this , FragmentTab.class);
                    startActivity( intent );
                    finish();
                }
                    break;
                case GO_GUIDE:
                {
                    Intent intent=new Intent( WelcomeAct.this,Guide.class );
                    startActivity( intent );
                    finish();
                }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.welcome );
        init();




    }




    //根据bool值，判定用户是否第一次进入
    private void init(){
        SharedPreferences prePreferences=getSharedPreferences( "zjq",MODE_PRIVATE );
        isFirstIn=prePreferences.getBoolean( "isFirstIn",true );
        if (!isFirstIn){
            mHandler.sendEmptyMessageDelayed(GO_HOME, TIME );
        }else {
            mHandler.sendEmptyMessageDelayed( GO_GUIDE, TIME);
            SharedPreferences.Editor editor=prePreferences.edit();
            editor.putBoolean( "isFirstIn",false );
            editor.commit();
        }
    }


}
