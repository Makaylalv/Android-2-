package com.example.zjq.my_app.Registration_Landing;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.zjq.my_app.Bean.User;
import com.example.zjq.my_app.Registration_Landing.Registration;
import com.example.zjq.my_app.R;
import com.mob.commons.utag.UserTag;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;

import static cn.smssdk.utils.a.e;

public class Registration_or_Landing extends AppCompatActivity {
    private EditText phone;
    private EditText password;
    private Button landing;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_or__landing);

        phone=findViewById( R.id.et_landing_telephone );
        password=findViewById( R.id.et_landing_password );
        landing=findViewById( R.id.btn_landing );


        landing.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //登录，查询
                Landing();
            }
        } );

    }

    private void Landing() {
        String p=phone.getText().toString();
        String ps=password.getText().toString();
        //查询
        BmobQuery<User> bmobQuery = new BmobQuery<User>();
        bmobQuery.getObject("c6166958cf", new QueryListener<User>() {
            @Override
            public void done(User object,BmobException e) {
                if(e==null){

                    Toast.makeText(Registration_or_Landing.this,"查询成功",Toast.LENGTH_SHORT).show();

                }else{

                    Toast.makeText(Registration_or_Landing.this,"查询失败：" + e.getMessage(),Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    //注册
    public void registration(View view){
        Intent it=new Intent(getApplicationContext(),Registration.class);
        startActivity(it);
    }
}
