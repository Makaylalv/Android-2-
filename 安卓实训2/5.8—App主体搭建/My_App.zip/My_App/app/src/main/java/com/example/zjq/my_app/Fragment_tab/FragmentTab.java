package com.example.zjq.my_app.Fragment_tab;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

import com.example.zjq.my_app.HomePage.HomePage;
import com.example.zjq.my_app.Order.Order_confirm;
import com.example.zjq.my_app.Order.Order_list;
import com.example.zjq.my_app.Personal.Personal_Information;
import com.example.zjq.my_app.R;

public class FragmentTab extends AppCompatActivity {

    private android.support.v4.app.FragmentTabHost tabHost;
    private  int[] tabHostIconNormal={R.drawable.app_tag_home_normal,R.drawable.app_tag_home_normal,R.drawable.app_tag_home_normal,R.drawable.app_tag_home_normal};
    private String[] tabHostText={"首页","我的订单","确认订单","个人中心"};
    private Class[] fragmentArr ={HomePage.class,Order_list.class,Order_confirm.class,Personal_Information.class};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_fragment_tab );

        initTabHost();
    }

    private void initTabHost() {
        tabHost=findViewById( android.R.id.tabhost );
        tabHost.setup( this,
                getSupportFragmentManager(),
                android.R.id.tabhost);
        for (int i=0;i<fragmentArr.length;++i){
            TabHost.TabSpec tabSpec=tabHost.newTabSpec( tabHostText[i] ).setIndicator(  getTabHostView( i ));
            tabHost.addTab( tabSpec,fragmentArr[i],null );
        }

    }
    private View getTabHostView(int index){
        View view = getLayoutInflater().inflate(R.layout.fragment_tab_tag,null);

        TextView textView = view.findViewById(R.id.tv_text);
        ImageView imageView = view.findViewById(R.id.iv_image);

        textView.setText(tabHostText[index]);
        imageView.setImageResource(tabHostIconNormal[index]);
        return view;


    }
}
